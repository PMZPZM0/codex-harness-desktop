@echo off  
"%~dp0..\node\node.exe" "%~dp0..\nuphus-call.mjs" %*  
